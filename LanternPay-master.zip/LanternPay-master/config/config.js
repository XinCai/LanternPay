'use strict';

function config() {
	//to do : add global config here 
};

module.exports = new config();