'use strict';
// store user data in maps for ease of use and readability...
var UserData = function() {
    this.login = {'username': 'Luke', 'password': 'Skywalker'};
    this.newemployee ={'firstname': 'Kevin', 'lastname': 'Cai', 'startDate':'2018-01-01','email':'caixin@hotmail.com'};
};
module.exports = new UserData();