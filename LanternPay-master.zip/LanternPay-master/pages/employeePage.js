'use strict';
var config = require('../config/config');

var employeePage = function () {

    this.createButton = element(by.id('bAdd'));
    this.firstName = element(by.model('selectedEmployee.firstName'));
    this.lastName = element(by.model('selectedEmployee.lastName'));
    this.email = element(by.model('selectedEmployee.email'));
    this.addButton = element(by.buttonText('Add'));
    this.startDate = element(by.model('selectedEmployee.startDate'));

    this.editButton = element(by.id('bEdit'));
    this.updateButton = element(by.cssContainingText('button', 'Update'));
    this.deleteButton = element(by.id('bDelete'));

    this.logoutButton = element(by.css('[ng-click="logout()"]'));

    //create employee
    this.createEmployee = function (fname, lname, startDate, email) {
        this.createButton.click();
        this.firstName.sendKeys(fname);
        this.lastName.sendKeys(lname);
        this.startDate.sendKeys(startDate);
        this.email.sendKeys(email);
        this.addButton.click();
    };

    //edit employee from oldValue to updateValue, identify target employee via csslocater
    this.editEmployee = function(csslocater,oldValue,updateValue){
        var empEdit = element(by.cssContainingText(csslocater, oldValue));
        empEdit.click();
        this.editButton.click();
        this.firstName.clear();
        this.firstName.sendKeys(updateValue);        
        this.updateButton.click();
    };

    //delete employee with nameValue and csslocater
    this.deleteEmployee = function(csslocater,nameValue){
        var empDelete = element(by.cssContainingText(csslocater,nameValue));
        empDelete.click();
        this.deleteButton.click();
        browser.switchTo().alert().accept();
        browser.driver.sleep(5000); // due to app performance , force to wait 5 sec , need to update later on
        browser.waitForAngular();
    };

    //logout employee page
    this.logoutEmployeePage = function(){
        this.logoutButton.click();
    };
};

module.exports = new employeePage();