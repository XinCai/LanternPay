'use strict';
var config = require('../config/config');
require('./employeePage.js');

var loginPage = function () {

    this.userName = element(by.model('user.name'));
    this.password = element(by.model('user.password'));
    this.loginButton = element(by.buttonText('Login'));

    this.enterLoginValue = function(user,password){
        this.userName.clear();
        this.password.clear();
        this.userName.sendKeys(user);
        this.password.sendKeys(password);
        this.loginButton.click();
        return require('./employeePage.js');
    };
};

module.exports = new loginPage();