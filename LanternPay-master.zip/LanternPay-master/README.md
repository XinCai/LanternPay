# LanternPay Test Demo

Task :
For this task you are required to utilise the Protractor, and Mocha/Jasmine framework to create a simple web test in JavaScript. You are required to perform the following tasks: 

1. Navigate to http://cafetownsend-angular-rails.herokuapp.com/login

2. Login to the app

3. Create a new employee and verify employee is created

4. Edit an employee and verify employee is updated

5. Delete the employee and verify employee is deleted

# Soultion
Protractor webdriver test using page object

0. clone project from github , can ignore node_modules folder. 
1. npm install 
2. to run test , run 'npm run test' 

# Environment: 
0. node version: v8.4.0
1. npm version: v5.3.0



