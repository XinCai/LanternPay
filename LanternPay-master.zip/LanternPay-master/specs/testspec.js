'use strict';

var loginPage = require('../pages/loginPage.js');
var userData = require('../data/userData.js');

describe('angular cafetownsend test', function() {

    it('should create  the named user', function() {
      
    browser.get('http://cafetownsend-angular-rails.herokuapp.com/login');
        
    var employeePage = loginPage.enterLoginValue(userData.login.username,userData.login.password); // page object return new employee page 

    var empBefore = element.all(by.repeater('employee in employees'));
    var countBefore;
    empBefore.count().then(function(count){
        countBefore = count;
        console.log("=======Count before add =====",count);
    });
    
    employeePage.createEmployee(
        userData.newemployee.firstname,
        userData.newemployee.lastname,
        userData.newemployee.startDate,
        userData.newemployee.email
    );

    //verify employee has been added
    var empAfter = element.all(by.repeater('employee in employees'));
    empAfter.count().then(function(count){
        console.log("=====count after add=====",count);
        expect(count).toBe(countBefore + 1);
    });

    //edit employee
    var empEdit = element(by.cssContainingText('#employee-list-container li', 'Kevin'));

    employeePage.editEmployee('#employee-list-container li','Kevin','Kevin01');

    //verify update sucessfully
    expect(empEdit.getText()).toBe("Kevin01 Cai");

    employeePage.deleteEmployee('#employee-list-container li','Kevin01');

    //logout and log back in to verify target employee has been deleted 
    employeePage.logoutEmployeePage();
    loginPage.enterLoginValue(userData.login.username,userData.login.password);

    //verify employee has been deleted 
    var elementsAfterDelete = element.all(by.cssContainingText('#employee-list li','Kevin'));
    elementsAfterDelete.count().then(function(count){
        expect(count).toBe(0);
        console.log('====== after delete target element, count =====',count);
        });
    });
});
  